library(testthat)
library(powers)

test_check("powers")
